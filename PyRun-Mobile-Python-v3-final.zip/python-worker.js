const PYODIDE_INDEX = "https://cdn.jsdelivr.net/pyodide/v314.0.7/full/";
import { loadPyodide } from "https://cdn.jsdelivr.net/pyodide/v314.0.7/full/pyodide.mjs";

let pyodide = null;
let busy = false;
let bootPromise = null;

function send(type, payload = {}) { self.postMessage({ type, ...payload }); }

async function boot() {
  if (bootPromise) return bootPromise;
  bootPromise = (async () => {
    try {
      send("status", { status: "loading" });
      pyodide = await loadPyodide({ indexURL: PYODIDE_INDEX });
      pyodide.setStdout({ batched: text => send("stream", { stream: "stdout", text }) });
      pyodide.setStderr({ batched: text => send("stream", { stream: "stderr", text }) });
      send("status", { status: "ready", version: pyodide.runPython("import sys; sys.version.split()[0]") });
    } catch (e) {
      bootPromise = null;
      send("fatal", { message: e?.stack || String(e) });
      throw e;
    }
  })();
  return bootPromise;
}

async function run(code) {
  await boot();
  if (busy) return;
  busy = true;
  send("run-start");
  const started = performance.now();
  try {
    // Load imported Pyodide-compatible packages only when a program asks for them.
    await pyodide.loadPackagesFromImports(code);
    pyodide.globals.set("USER_CODE", code);
    const result = await pyodide.runPythonAsync(`
import io, contextlib, traceback, ast, json
_out = io.StringIO()
_err = io.StringIO()
_exc = None
try:
    _tree = ast.parse(USER_CODE)
    with contextlib.redirect_stdout(_out), contextlib.redirect_stderr(_err):
        exec(compile(_tree, "<main.py>", "exec"), globals(), globals())
except BaseException as e:
    _exc = e
_stdout = _out.getvalue()
_stderr = _err.getvalue()
_problem = None if _exc is None else {
    "type": type(_exc).__name__,
    "message": str(_exc),
    "traceback": traceback.format_exc()
}
_vars = {}
for _k, _v in list(globals().items()):
    if _k.startswith("_") or _k == "USER_CODE": continue
    try:
        if isinstance(_v, (str, int, float, bool, list, dict, tuple, set, type(None))):
            _vars[_k] = repr(_v)
        elif callable(_v):
            _vars[_k] = "<function>"
        else:
            _vars[_k] = f"<{type(_v).__name__}>"
    except Exception:
        _vars[_k] = "<unavailable>"
json.dumps({"stdout": _stdout, "stderr": _stderr, "problem": _problem, "vars": _vars})
`, { optimize: 1 });
    send("result", { data: JSON.parse(result), ms: Math.round(performance.now() - started) });
  } catch (e) {
    send("result", { data: { stdout: "", stderr: "", problem: { type: e?.name || "Error", message: e?.message || String(e), traceback: e?.stack || String(e) }, vars: {} }, ms: Math.round(performance.now() - started) });
  } finally {
    busy = false;
    send("run-end");
  }
}

async function terminal(code) {
  await boot();
  if (busy) return;
  try {
    pyodide.globals.set("TERMINAL_CODE", code);
    const result = await pyodide.runPythonAsync(`
import io, contextlib, json
_b = io.StringIO()
try:
    with contextlib.redirect_stdout(_b):
        _r = eval(TERMINAL_CODE, globals(), globals())
    _ans = repr(_r) if _r is not None else ""
except Exception as e:
    _ans = f"{type(e).__name__}: {e}"
json.dumps({"out": _b.getvalue(), "ans": _ans})
`, { optimize: 1 });
    send("terminal-result", { data: JSON.parse(result) });
  } catch (e) {
    send("terminal-result", { data: { out: "", ans: String(e) } });
  }
}

self.onmessage = async (event) => {
  const { type, code } = event.data || {};
  try {
    if (type === "run") await run(String(code || ""));
    else if (type === "terminal") await terminal(String(code || ""));
    else if (type === "boot") await boot();
  } catch (_) {}
};

boot();
