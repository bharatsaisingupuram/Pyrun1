# PyRun 🐍

A mobile-first Python playground that runs Python directly in the browser with Pyodide.

## Files
- `index.html` — UI
- `style.css` — responsive/cute mobile styling
- `script.js` — app logic, syllabus, files, history, practice
- `python-worker.js` — Python runtime worker

## Run
Use VS Code + Live Server, or any HTTPS/static host. Open `index.html`.

The Python engine is loaded from the official Pyodide CDN. Pyodide runs CPython through WebAssembly in the browser, and this project puts execution in a Web Worker so the UI remains responsive.

## Important production notes
This version stores files/history in localStorage and does not include accounts/cloud synchronization. Pyodide runs in a module Web Worker and the browser CDN cache is used for repeat visits. For a 10,000+ concurrent-user public service, add authentication, a database, server-side rate limiting, monitoring, CDN/static hosting, and load testing.

Interactive `input()` needs a dedicated asynchronous stdin UX; this build intentionally does not fake it with a blocking prompt. The editor and terminal remain responsive.

## GitHub
Upload the files to a repository and enable GitHub Pages. Because this app is static, GitHub Pages can serve it. HTTPS hosting is recommended.
