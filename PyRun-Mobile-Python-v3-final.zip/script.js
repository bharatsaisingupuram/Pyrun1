const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const TOPICS = [
["Variables & Syntax","name = 'Bharat'","name = 'Bharat'\nprint(name)"],
["Data Types","int, float, str, bool","x = 10\nprice = 9.5\nname = 'Bharat'\nactive = True"],
["Input / Output","input(), print()","name = input('Name: ')\nprint('Hello', name)"],
["Operators","+  -  *  /  //  %  **","a = 10\nb = 3\nprint(a + b)\nprint(a ** b)"],
["if / elif / else","Decision making","age = 18\nif age >= 18:\n    print('Adult')\nelse:\n    print('Minor')"],
["for loop","Repeat over a sequence","for i in range(1, 6):\n    print(i)"],
["while loop","Repeat while true","i = 1\nwhile i <= 5:\n    print(i)\n    i += 1"],
["Functions","def + return","def add(a, b):\n    return a + b\n\nprint(add(2, 3))"],
["Strings","Text operations","text = 'Python'\nprint(text.upper())\nprint(text[0:3])"],
["Lists","Mutable collection","numbers = [10, 20, 30]\nnumbers.append(40)\nprint(numbers)"],
["Tuples","Immutable collection","point = (10, 20)\nprint(point[0])"],
["Sets","Unique values","items = {1, 2, 2, 3}\nprint(items)"],
["Dictionaries","Key-value data","student = {'name':'Bharat','age':18}\nprint(student['name'])"],
["List Comprehension","Compact list creation","squares = [x*x for x in range(1, 6)]\nprint(squares)"],
["Exceptions","try / except","try:\n    x = int(input('Number: '))\nexcept ValueError:\n    print('Please enter a number')"],
["Files","open / read / write","with open('notes.txt', 'w') as f:\n    f.write('Hello Python')"],
["Modules","import libraries","import math\nprint(math.sqrt(25))"],
["Lambda","Small anonymous function","square = lambda x: x*x\nprint(square(5))"],
["Recursion","Function calling itself","def fact(n):\n    if n <= 1: return 1\n    return n * fact(n-1)\nprint(fact(5))"],
["Classes & Objects","OOP basics","class Student:\n    def __init__(self, name):\n        self.name = name\n\ns = Student('Bharat')\nprint(s.name)"],
["Inheritance","Reuse a parent class","class Animal:\n    def speak(self): print('sound')\nclass Dog(Animal): pass\nDog().speak()"],
["Iterators","iter / next","nums = iter([1,2,3])\nprint(next(nums))"],
["Decorators","Wrap functions","def log(fn):\n    def wrapper():\n        print('Running')\n        return fn()\n    return wrapper"],
["Regular Expressions","re module","import re\nprint(re.findall(r'\\d+', 'Age 18'))"]
];

const QUICK = [
["print","print('Hello')"],["input","name = input('Name: ')"],["if","if condition:\n    pass"],["for","for i in range(5):\n    print(i)"],["while","while condition:\n    pass"],["def","def function_name():\n    pass"],["list","items = []"],["dict","data = {}"],["try","try:\n    pass\nexcept Exception as e:\n    print(e)"],["class","class MyClass:\n    pass"],["import","import math"],["f-string","print(f'Value: {x}')"]
];

const PROBLEMS = [
["Even or Odd","Read an integer and print whether it is even or odd.","n = int(input('Enter number: '))\n# write your solution here"],
["Largest of Three","Read three numbers and print the largest.","a = int(input('A: '))\nb = int(input('B: '))\nc = int(input('C: '))\n# write your solution here"],
["Sum of List","Find the sum of all numbers in a list.","numbers = [5, 10, 15, 20]\n# write your solution here"],
["Factorial","Write a function that returns the factorial of n.","def factorial(n):\n    # write your solution here\n    pass\n\nprint(factorial(5))"],
["Palindrome","Check whether a word reads the same backwards.","word = input('Word: ')\n# write your solution here"],
["Fibonacci","Print the first n Fibonacci numbers.","n = int(input('How many: '))\n# write your solution here"],
["Count Vowels","Count vowels in a sentence.","text = input('Text: ')\n# write your solution here"]
];

const editor = $("#editor");
const output = $("#output");
const lineNumbers = $("#lineNumbers");
let worker;
let pyReady = false;
function createWorker(){
  worker = new Worker("python-worker.js");
  worker.onmessage = handleWorkerMessage;
}
createWorker();
let currentFile = "main.py", files = JSON.parse(localStorage.getItem("pyrun-files") || "{}");
let runHistory = JSON.parse(localStorage.getItem("pyrun-history") || "[]");
let lastVars = {};

if (!files["main.py"]) files["main.py"] = editor.value;
else editor.value = files["main.py"];

function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
function saveFiles(){localStorage.setItem("pyrun-files",JSON.stringify(files));$("#saveState").textContent="● Saved locally"}
function saveCurrent(){
  currentFile=$("#fileName").value.trim()||"main.py";
  if(!currentFile.endsWith(".py")) currentFile+=".py";
  $("#fileName").value=currentFile;
  files[currentFile]=editor.value;saveFiles();renderFiles();toast("Saved ✓");
}
function loadFile(name){saveCurrent();currentFile=name;$("#fileName").value=name;editor.value=files[name]||"";updateLines();closeModal()}
function renderFiles(){
  $("#fileList").innerHTML=Object.keys(files).map(n=>`<div class="file-row"><span>🐍 ${escapeHtml(n)}</span><button data-file="${escapeAttr(n)}">Open</button></div>`).join("");
  $$("#fileList button").forEach(b=>b.onclick=()=>loadFile(b.dataset.file));
}
function closeModal(){$("#filesModal").classList.add("hidden")}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function escapeAttr(s){return s.replace(/"/g,"&quot;")}

function updateLines(){
  const count=editor.value.split("\n").length;
  lineNumbers.textContent=Array.from({length:count},(_,i)=>i+1).join("\n");
}
editor.addEventListener("input",()=>{updateLines();$("#saveState").textContent="● Unsaved";});
editor.addEventListener("scroll",()=>{lineNumbers.scrollTop=editor.scrollTop});
editor.addEventListener("keydown",e=>{
  if(e.key==="Tab"){e.preventDefault();const a=editor.selectionStart,b=editor.selectionEnd;editor.setRangeText("    ",a,b,"end")}
  if((e.ctrlKey||e.metaKey)&&e.key==="s"){e.preventDefault();saveCurrent()}
});
updateLines();

function insertCode(code){
  const a=editor.selectionStart,b=editor.selectionEnd;
  const before=editor.value.slice(0,a), after=editor.value.slice(b);
  const prefix=before && !before.endsWith("\n") ? "\n" : "";
  editor.setRangeText(prefix+code+"\n",a,b,"end");editor.focus();updateLines();$("#saveState").textContent="● Unsaved";
}
$("#syntaxPad").innerHTML=QUICK.map(([n,c])=>`<button data-code="${encodeURIComponent(c)}">${n}</button>`).join("");
$$("[data-code]").forEach(b=>b.onclick=()=>insertCode(decodeURIComponent(b.dataset.code)));

function renderSyllabus(filter=""){
  const f=filter.toLowerCase();
  $("#syllabus").innerHTML=TOPICS.filter(x=>x[0].toLowerCase().includes(f)||x[1].toLowerCase().includes(f))
  .map(([n,d,c])=>`<div class="topic"><strong>${escapeHtml(n)}</strong><small>${escapeHtml(d)}</small><button data-topic="${encodeURIComponent(c)}">Insert example</button></div>`).join("")||`<div class="empty-panel">No topic found.</div>`;
  $$("#syllabus [data-topic]").forEach(b=>b.onclick=()=>insertCode(decodeURIComponent(b.dataset.topic)));
}
renderSyllabus();$("#topicSearch").oninput=e=>renderSyllabus(e.target.value);

function renderProblems(){
  $("#problemsList").innerHTML=PROBLEMS.map((p,i)=>`<div class="practice-item"><strong>${i+1}. ${escapeHtml(p[0])}</strong><p>${escapeHtml(p[1])}</p><button data-problem="${i}">Start problem</button></div>`).join("");
  $$("#problemsList [data-problem]").forEach(b=>b.onclick=()=>{editor.value=PROBLEMS[+b.dataset.problem][2];updateLines();editor.focus();$("#saveState").textContent="● Unsaved";window.scrollTo({top:0,behavior:"smooth"});toast("Problem loaded 🧩")});
}
renderProblems();$("#randomProblem").onclick=()=>{$$("#problemsList [data-problem]")[Math.floor(Math.random()*PROBLEMS.length)].click()};

function showTab(name){
  $$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===name));
  $$(".panel").forEach(p=>p.classList.remove("active"));
  $(`#${name}Panel`).classList.add("active");
}
$$(".tab").forEach(b=>b.onclick=()=>showTab(b.dataset.tab));

function setOutput(text){output.textContent=text||"Program finished with no output.";output.scrollTop=output.scrollHeight}
function problemHTML(p){
  if(!p) return `<div class="empty-panel">No problems detected. ✨</div>`;
  return `<div style="padding:15px"><strong>❌ ${escapeHtml(p.type)}</strong><p>${escapeHtml(p.message||"")}</p><pre class="console-output">${escapeHtml(p.traceback||"")}</pre></div>`;
}
function renderDebug(){
  const entries=Object.entries(lastVars);
  if(!entries.length){$("#debug").innerHTML='<div class="empty-panel">No simple variables were captured.</div>';return}
  $("#debug").innerHTML=`<table class="debug-table">${entries.map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(v)}</td></tr>`).join("")}</table>`;
}
function renderHistory(){
  $("#history").innerHTML=runHistory.length?runHistory.slice().reverse().map(h=>`<div class="file-row"><span><b>${escapeHtml(h.file)}</b> · ${h.time} · ${h.ms}ms</span><button data-hist="${h.id}">Load</button></div>`).join(""):'<div class="empty-panel">No runs yet.</div>';
  $$("#history [data-hist]").forEach(b=>b.onclick=()=>{const h=runHistory.find(x=>x.id===b.dataset.hist);if(h){editor.value=h.code;updateLines();window.scrollTo({top:0,behavior:"smooth"})}});
}

function handleWorkerMessage(e){
  const m=e.data;
  if(m.type==="stream"){
    if(m.stream === "stdout") output.textContent += m.text;
    else output.textContent += "\n" + m.text;
    output.scrollTop = output.scrollHeight;
  }
  if(m.type==="status"){
    if(m.status==="loading"){output.innerHTML='<span class="muted">🐍 Loading Python engine… first load can take a little longer.</span>';$("#runBtn").disabled=true}
    if(m.status==="ready"){pyReady=true;$("#runBtn").disabled=false;output.textContent=`Python ${m.version} ready ✓\n\nPress ▶ Run Python.`;toast("Python is ready 🐍")}
  }
  if(m.type==="run-start"){$("#stopBtn").disabled=false;$("#runBtn").disabled=true}
  if(m.type==="run-end"){$("#stopBtn").disabled=true;$("#runBtn").disabled=false}
  if(m.type==="result"){
    const d=m.data;let text=(d.stdout||"")+(d.stderr?`\n${d.stderr}`:"");
    if(d.problem){text+=`\n\n❌ ${d.problem.type}: ${d.problem.message}`;$("#problems").innerHTML=problemHTML(d.problem)}else{$("#problems").innerHTML='<div class="empty-panel">No problems detected. ✨</div>'}
    if(text.trim()) setOutput(text);
    lastVars=d.vars||{};renderDebug();
    $("#problemCount").textContent=d.problem?1:0;
    const h={id:String(Date.now())+String(Math.random()).slice(2,8),file:currentFile,code:editor.value,ms:m.ms,time:new Date().toLocaleTimeString()};
    runHistory.push(h);runHistory=runHistory.slice(-30);localStorage.setItem("pyrun-history",JSON.stringify(runHistory));renderHistory();
  }
  if(m.type==="fatal"){pyReady=false; output.textContent="Python engine failed to load.\n"+m.message; $("#runBtn").disabled=true}
  if(m.type==="terminal-result"){
    const d=m.data;$("#terminal").textContent+=(d.out||"")+(d.ans?d.ans+"\n":"");$("#terminal").scrollTop=$("#terminal").scrollHeight;
  }
};

$("#runBtn").onclick=()=>{
  if(!pyReady){toast("Python is still loading…");return}
  saveCurrent();showTab("output");worker.postMessage({type:"run",code:editor.value});
};
$("#stopBtn").onclick=()=>{
  worker.terminate();
  createWorker();
  pyReady=false;
  $("#stopBtn").disabled=true;
  $("#runBtn").disabled=true;
  output.textContent="Python worker restarted. Loading Python engine…";
  toast("Execution stopped • restarting Python…");
};
$("#saveBtn").onclick=saveCurrent;
$("#filesBtn").onclick=()=>{$("#filesModal").classList.remove("hidden");renderFiles()};
$("#closeFiles").onclick=closeModal;
$("#modalNew").onclick=()=>{
  const n=prompt("New Python file name","practice.py");if(!n)return;
  let name=n.endsWith(".py")?n:n+".py";if(files[name]){toast("File already exists");return}
  files[name]="# New Python file\n\n";saveFiles();loadFile(name);
};
$("#newBtn").onclick=()=>{editor.value="# New Python file\n\n";$("#fileName").value="untitled.py";currentFile="untitled.py";updateLines();toast("New file created")};
$("#clearBtn").onclick=()=>setOutput("");
$("#refreshDebug").onclick=renderDebug;
$("#themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("pyrun-dark",document.body.classList.contains("dark"))};
if(localStorage.getItem("pyrun-dark")==="true")document.body.classList.add("dark");
renderFiles();renderHistory();

$("#terminalInput").addEventListener("keydown",e=>{
  if(e.key==="Enter"){const v=e.target.value.trim();if(!v)return;$("#terminal").textContent+=`>>> ${v}\n`;worker.postMessage({type:"terminal",code:v});e.target.value=""}
});
$("#stdinInput").addEventListener("keydown",e=>{if(e.key==="Enter")toast("Input support is enabled through the Python browser console; interactive stdin is limited in this MVP.")});
$$(".bottom-nav button").forEach(b=>b.onclick=()=>{const el=$(`.${b.dataset.scroll}`);el?.scrollIntoView({behavior:"smooth",block:"start"})});
